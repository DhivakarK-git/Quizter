#!/bin/bash

echo "Running python manage.py testing command:"
python manage.py test quizter/quizApp/tests 
